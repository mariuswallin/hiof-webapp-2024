function App() {
  return <h1>Hey</h1>;
}

export default App;
